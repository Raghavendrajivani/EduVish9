(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [7601],
  {
    55903: function (e, t, n) {
      Promise.resolve().then(n.bind(n, 97013));
    },
    97013: function (e, t, n) {
      "use strict";
      (n.r(t),
        n.d(t, {
          default: function () {
            return u;
          },
        }));
      var r = n(57437),
        o = n(2265),
        i = n(12381);
      let s = (0, n(96471).Z)("TriangleAlert", [
        [
          "path",
          {
            d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
            key: "wmoenq",
          },
        ],
        ["path", { d: "M12 9v4", key: "juzpu7" }],
        ["path", { d: "M12 17h.01", key: "p32p05" }],
      ]);
      function u(e) {
        let { error: t, reset: n } = e;
        return (
          (0, o.useEffect)(() => {
            console.error(t);
          }, [t]),
          (0, r.jsx)("div", {
            className:
              "flex flex-col items-center justify-center min-h-[50vh] bg-background text-foreground p-4",
            children: (0, r.jsxs)("div", {
              className: "text-center max-w-lg",
              children: [
                (0, r.jsx)(s, {
                  className: "mx-auto h-16 w-16 text-destructive mb-4",
                }),
                (0, r.jsx)("h1", {
                  className: "text-3xl font-bold text-destructive mb-2",
                  children: "Oops! Something went wrong.",
                }),
                (0, r.jsx)("p", {
                  className: "text-muted-foreground mb-6",
                  children:
                    "We've encountered an unexpected error. Our team has been notified, but you can also help by trying again.",
                }),
                (0, r.jsx)(i.z, {
                  onClick: () => n(),
                  size: "lg",
                  children: "Try Again",
                }),
              ],
            }),
          })
        );
      }
    },
    12381: function (e, t, n) {
      "use strict";
      n.d(t, {
        d: function () {
          return a;
        },
        z: function () {
          return c;
        },
      });
      var r = n(57437),
        o = n(2265),
        i = n(98482),
        s = n(90535),
        u = n(93448);
      let a = (0, s.j)(
          "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
          {
            variants: {
              variant: {
                default:
                  "bg-primary text-primary-foreground hover:bg-primary/90",
                destructive:
                  "bg-destructive text-destructive-foreground hover:bg-destructive/90",
                outline:
                  "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
                secondary:
                  "bg-secondary text-secondary-foreground hover:bg-secondary/80",
                ghost: "hover:bg-accent hover:text-accent-foreground",
                link: "text-primary underline-offset-4 hover:underline",
              },
              size: {
                default: "h-10 px-4 py-2",
                sm: "h-9 rounded-md px-3",
                lg: "h-11 rounded-md px-8",
                icon: "h-10 w-10",
              },
            },
            defaultVariants: { variant: "default", size: "default" },
          },
        ),
        c = o.forwardRef((e, t) => {
          let { className: n, variant: o, size: s, asChild: c = !1, ...d } = e,
            l = c ? i.g7 : "button";
          return (0, r.jsx)(l, {
            className: (0, u.cn)(a({ variant: o, size: s, className: n })),
            ref: t,
            ...d,
          });
        });
      c.displayName = "Button";
    },
    93448: function (e, t, n) {
      "use strict";
      n.d(t, {
        cn: function () {
          return i;
        },
      });
      var r = n(61994),
        o = n(53335);
      function i() {
        for (var e = arguments.length, t = Array(e), n = 0; n < e; n++)
          t[n] = arguments[n];
        return (0, o.m6)((0, r.W)(t));
      }
      n(40257);
    },
  },
  function (e) {
    (e.O(0, [167, 2971, 2117, 1744], function () {
      return e((e.s = 55903));
    }),
      (_N_E = e.O()));
  },
]);
