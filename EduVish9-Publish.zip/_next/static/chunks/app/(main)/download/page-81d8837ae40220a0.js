(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1698],
  {
    32469: function (e, t, a) {
      Promise.resolve().then(a.bind(a, 75191));
    },
    63515: function (e, t) {
      "use strict";
      (Object.defineProperty(t, "__esModule", { value: !0 }),
        (function (e, t) {
          for (var a in t)
            Object.defineProperty(e, a, { enumerable: !0, get: t[a] });
        })(t, {
          cancelIdleCallback: function () {
            return r;
          },
          requestIdleCallback: function () {
            return a;
          },
        }));
      let a =
          ("undefined" != typeof self &&
            self.requestIdleCallback &&
            self.requestIdleCallback.bind(window)) ||
          function (e) {
            let t = Date.now();
            return self.setTimeout(function () {
              e({
                didTimeout: !1,
                timeRemaining: function () {
                  return Math.max(0, 50 - (Date.now() - t));
                },
              });
            }, 1);
          },
        r =
          ("undefined" != typeof self &&
            self.cancelIdleCallback &&
            self.cancelIdleCallback.bind(window)) ||
          function (e) {
            return clearTimeout(e);
          };
      ("function" == typeof t.default ||
        ("object" == typeof t.default && null !== t.default)) &&
        void 0 === t.default.__esModule &&
        (Object.defineProperty(t.default, "__esModule", { value: !0 }),
        Object.assign(t.default, t),
        (e.exports = t.default));
    },
    75191: function (e, t, a) {
      "use strict";
      (a.r(t),
        a.d(t, {
          default: function () {
            return w;
          },
        }));
      var r = a(57437),
        n = a(79820),
        i = a(96471);
      let s = (0, i.Z)("EllipsisVertical", [
        ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
        ["circle", { cx: "12", cy: "5", r: "1", key: "gxeob9" }],
        ["circle", { cx: "12", cy: "19", r: "1", key: "lyex9k" }],
      ]);
      var l = a(40655);
      let d = (0, i.Z)("CircleCheck", [
          ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
          ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }],
        ]),
        o = (0, i.Z)("Share", [
          [
            "path",
            { d: "M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8", key: "1b2hhj" },
          ],
          ["polyline", { points: "16 6 12 2 8 6", key: "m901s6" }],
          ["line", { x1: "12", x2: "12", y1: "2", y2: "15", key: "1p0rca" }],
        ]),
        c = (0, i.Z)("SquarePlus", [
          [
            "rect",
            {
              width: "18",
              height: "18",
              x: "3",
              y: "3",
              rx: "2",
              key: "afitv7",
            },
          ],
          ["path", { d: "M8 12h8", key: "1wcyev" }],
          ["path", { d: "M12 8v8", key: "napkw2" }],
        ]),
        u = (0, i.Z)("Tv", [
          [
            "rect",
            {
              width: "20",
              height: "15",
              x: "2",
              y: "7",
              rx: "2",
              ry: "2",
              key: "10ag99",
            },
          ],
          ["polyline", { points: "17 2 12 7 7 2", key: "11pgbg" }],
        ]),
        f = (0, i.Z)("Zap", [
          [
            "path",
            {
              d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
              key: "1xq2db",
            },
          ],
        ]),
        m = (0, i.Z)("WifiOff", [
          ["path", { d: "M12 20h.01", key: "zekei9" }],
          ["path", { d: "M8.5 16.429a5 5 0 0 1 7 0", key: "1bycff" }],
          ["path", { d: "M5 12.859a10 10 0 0 1 5.17-2.69", key: "1dl1wf" }],
          ["path", { d: "M19 12.859a10 10 0 0 0-2.007-1.523", key: "4k23kn" }],
          ["path", { d: "M2 8.82a15 15 0 0 1 4.177-2.643", key: "1grhjp" }],
          ["path", { d: "M22 8.82a15 15 0 0 0-11.288-3.764", key: "z3jwby" }],
          ["path", { d: "m2 2 20 20", key: "1ooewy" }],
        ]),
        p = (0, i.Z)("Link", [
          [
            "path",
            {
              d: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71",
              key: "1cjeqo",
            },
          ],
          [
            "path",
            {
              d: "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71",
              key: "19qd67",
            },
          ],
        ]);
      var h = a(33804),
        x = a(2265);
      function y() {
        let [e, t] = (0, x.useState)(!1);
        return ((0, x.useEffect)(() => {
          let e = window.navigator.userAgent.toLowerCase();
          t(/android/i.test(e));
        }, []),
        e)
          ? (0, r.jsxs)("div", {
              className:
                "bg-primary/10 border border-primary/20 rounded-lg p-4 mb-4",
              children: [
                (0, r.jsx)("h3", {
                  className: "font-bold text-primary mb-2",
                  children: "Android Detected",
                }),
                (0, r.jsx)("p", {
                  className: "text-sm text-muted-foreground",
                  children:
                    "You are using an Android device. Please follow the steps below to install EduVish9 to your home screen.",
                }),
              ],
            })
          : null;
      }
      var g = a(83608),
        b = a(12381),
        j = a(48667);
      function w() {
        let [e, t] = (0, x.useState)(null);
        (0, x.useEffect)(() => {
          let e = (e) => {
            (e.preventDefault(), t(e));
          };
          return (
            window.addEventListener("beforeinstallprompt", e),
            () => {
              window.removeEventListener("beforeinstallprompt", e);
            }
          );
        }, []);
        let a = [
            {
              title: "Open the Menu",
              instruction:
                "Tap the three-dot menu icon at the top-right corner of your browser.",
              icon: (0, r.jsx)(s, { className: "w-5 h-5 text-primary" }),
            },
            {
              title: "Select 'Install app'",
              instruction:
                "Look for and tap on the 'Install app' or 'Add to Home screen' option in the menu.",
              icon: (0, r.jsx)(l.Z, { className: "w-5 h-5 text-primary" }),
            },
            {
              title: "Confirm Installation",
              instruction:
                "A pop-up will appear. Tap 'Install' to add the EduVish9 icon to your home screen.",
              icon: (0, r.jsx)(d, { className: "w-5 h-5 text-primary" }),
            },
          ],
          i = [
            {
              title: "Open the Share Menu",
              instruction:
                "Tap the 'Share' icon at the bottom of the Safari browser screen.",
              icon: (0, r.jsx)(o, { className: "w-6 h-6" }),
            },
            {
              title: "Add to Home Screen",
              instruction:
                "Scroll down in the share sheet and tap on 'Add to Home Screen'.",
              icon: (0, r.jsx)(c, { className: "w-6 h-6" }),
            },
            {
              title: "Confirm and Add",
              instruction:
                "You can rename the app if you wish, then tap 'Add' in the top-right corner to place it on your home screen.",
              icon: (0, r.jsx)(d, { className: "w-6 h-6" }),
            },
          ],
          w = [
            {
              icon: (0, r.jsx)(u, { className: "w-5 h-5 text-primary" }),
              feature: "App-like Experience",
              benefit:
                "Launch it directly from your home screen just like a native app.",
            },
            {
              icon: (0, r.jsx)(f, { className: "w-5 h-5 text-primary" }),
              feature: "Faster Performance",
              benefit: "Enjoy quicker loading times and smoother navigation.",
            },
            {
              icon: (0, r.jsx)(m, { className: "w-5 h-5 text-primary" }),
              feature: "Offline Access",
              benefit:
                "Access downloaded materials even without an internet connection.",
            },
            {
              icon: (0, r.jsx)(p, { className: "w-5 h-5 text-primary" }),
              feature: "Instant Access",
              benefit: "No need to open a browser and type the URL every time.",
            },
          ];
        return (0, r.jsxs)("div", {
          className: "max-w-7xl mx-auto space-y-12 px-4 sm:px-0",
          "data-ai-id": "download-page-container",
          children: [
            (0, r.jsx)(j.default, {
              type: "application/ld+json",
              dangerouslySetInnerHTML: {
                __html: JSON.stringify({
                  "@context": "https://schema.org",
                  "@type": "SoftwareApplication",
                  name: "EduVish9",
                  operatingSystem: "WEB, ANDROID, IOS",
                  applicationCategory: "EducationalApplication",
                  aggregateRating: {
                    "@type": "AggregateRating",
                    ratingValue: "4.8",
                    ratingCount: "250",
                  },
                  offers: {
                    "@type": "Offer",
                    price: "0",
                    priceCurrency: "USD",
                  },
                }),
              },
            }),
            (0, r.jsx)(g.BackButton, {}),
            (0, r.jsxs)("section", {
              className: "text-center",
              "data-ai-id": "download-page-header",
              children: [
                (0, r.jsx)("h1", {
                  className:
                    "text-3xl sm:text-4xl font-headline font-bold tracking-tight text-gradient",
                  "data-ai-id": "download-page-heading",
                  children: "Install EduVish9",
                }),
                (0, r.jsx)("p", {
                  className:
                    "text-base sm:text-lg text-muted-foreground mt-2 max-w-2xl mx-auto",
                  "data-ai-id": "download-page-subheading",
                  children:
                    "Get quick access to all your study materials by adding EduVish9 to your home screen. It’s fast, free, and works offline!",
                }),
              ],
            }),
            e &&
              (0, r.jsxs)(n.Zb, {
                className: "bg-primary/10 border-primary/20 animate-fade-in-up",
                children: [
                  (0, r.jsxs)(n.Ol, {
                    className: "text-center",
                    children: [
                      (0, r.jsx)(n.ll, {
                        children: "One-Click Install Available!",
                      }),
                      (0, r.jsx)(n.SZ, {
                        children: "Your browser supports direct installation.",
                      }),
                    ],
                  }),
                  (0, r.jsx)(n.aY, {
                    className: "flex justify-center",
                    children: (0, r.jsxs)(b.z, {
                      size: "lg",
                      onClick: () => {
                        e &&
                          (e.prompt(),
                          e.userChoice.then((e) => {
                            ("accepted" === e.outcome
                              ? console.log("User accepted the install prompt")
                              : console.log(
                                  "User dismissed the install prompt",
                                ),
                              t(null));
                          }));
                      },
                      children: [
                        (0, r.jsx)(l.Z, { className: "mr-2 h-5 w-5" }),
                        "Install EduVish9 App Now",
                      ],
                    }),
                  }),
                ],
              }),
            (0, r.jsxs)("div", {
              className: "grid grid-cols-1 lg:grid-cols-2 gap-8",
              "data-ai-id": "download-guides-grid",
              children: [
                (0, r.jsxs)(n.Zb, {
                  "data-ai-id": "android-guide-card",
                  children: [
                    (0, r.jsxs)(n.Ol, {
                      children: [
                        (0, r.jsx)(n.ll, {
                          className: "text-2xl font-semibold",
                          "data-ai-id": "android-guide-title",
                          children: "For Android Users",
                        }),
                        (0, r.jsx)(n.SZ, {
                          "data-ai-id": "android-guide-desc",
                          children: "Using Chrome or a Chromium-based browser.",
                        }),
                      ],
                    }),
                    (0, r.jsxs)(n.aY, {
                      className: "pt-2 space-y-6",
                      children: [
                        (0, r.jsx)(y, {}),
                        a.map((e, t) =>
                          (0, r.jsxs)(
                            "div",
                            {
                              className: "flex items-start gap-4",
                              "data-ai-id": "android-step-".concat(t + 1),
                              children: [
                                (0, r.jsx)("div", {
                                  className:
                                    "flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg",
                                  children: t + 1,
                                }),
                                (0, r.jsxs)("div", {
                                  className: "flex-grow pt-1",
                                  children: [
                                    (0, r.jsxs)("p", {
                                      className:
                                        "font-semibold text-lg flex items-center gap-2",
                                      children: [e.icon, e.title],
                                    }),
                                    (0, r.jsx)("p", {
                                      className: "text-muted-foreground mt-1",
                                      children: e.instruction,
                                    }),
                                  ],
                                }),
                              ],
                            },
                            t,
                          ),
                        ),
                      ],
                    }),
                  ],
                }),
                (0, r.jsxs)(n.Zb, {
                  "data-ai-id": "ios-guide-card",
                  children: [
                    (0, r.jsxs)(n.Ol, {
                      children: [
                        (0, r.jsx)(n.ll, {
                          className: "text-2xl font-semibold",
                          "data-ai-id": "ios-guide-title",
                          children: "For iOS (iPhone/iPad) Users",
                        }),
                        (0, r.jsx)(n.SZ, {
                          "data-ai-id": "ios-guide-desc",
                          children: "Using the Safari browser.",
                        }),
                      ],
                    }),
                    (0, r.jsx)(n.aY, {
                      className: "pt-6 space-y-6",
                      children: i.map((e, t) =>
                        (0, r.jsxs)(
                          "li",
                          {
                            className: "flex items-start gap-4 list-none",
                            "data-ai-id": "ios-step-".concat(t + 1),
                            children: [
                              (0, r.jsx)("div", {
                                className:
                                  "flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg",
                                children: t + 1,
                              }),
                              (0, r.jsxs)("div", {
                                className: "flex-grow pt-1",
                                children: [
                                  (0, r.jsxs)("p", {
                                    className:
                                      "font-semibold text-lg flex items-center gap-2",
                                    children: [
                                      (0, r.jsx)("span", {
                                        className: "text-primary",
                                        children: e.icon,
                                      }),
                                      e.title,
                                    ],
                                  }),
                                  (0, r.jsx)("p", {
                                    className: "text-muted-foreground mt-1",
                                    children: e.instruction,
                                  }),
                                ],
                              }),
                            ],
                          },
                          t,
                        ),
                      ),
                    }),
                  ],
                }),
              ],
            }),
            (0, r.jsxs)(n.Zb, {
              "data-ai-id": "benefits-card",
              children: [
                (0, r.jsxs)(n.Ol, {
                  children: [
                    (0, r.jsx)(n.ll, {
                      className:
                        "text-2xl font-semibold text-center text-gradient",
                      "data-ai-id": "benefits-title",
                      children: "Benefits of Installing the EduVish9 App",
                    }),
                    (0, r.jsx)(n.SZ, {
                      className: "text-center",
                      "data-ai-id": "benefits-desc",
                      children:
                        "Get the best experience by adding our app to your home screen.",
                    }),
                  ],
                }),
                (0, r.jsx)(n.aY, {
                  children: (0, r.jsxs)(h.iA, {
                    children: [
                      (0, r.jsx)(h.xD, {
                        children: (0, r.jsxs)(h.SC, {
                          children: [
                            (0, r.jsx)(h.ss, {
                              className: "w-[200px]",
                              "data-ai-id": "benefits-table-header-feature",
                              children: "Feature",
                            }),
                            (0, r.jsx)(h.ss, {
                              "data-ai-id": "benefits-table-header-benefit",
                              children: "Benefit",
                            }),
                          ],
                        }),
                      }),
                      (0, r.jsx)(h.RM, {
                        children: w.map((e, t) =>
                          (0, r.jsxs)(
                            h.SC,
                            {
                              "data-ai-id": "benefit-row-".concat(t + 1),
                              children: [
                                (0, r.jsxs)(h.pj, {
                                  className:
                                    "font-semibold flex items-center gap-2",
                                  children: [e.icon, " ", e.feature],
                                }),
                                (0, r.jsx)(h.pj, { children: e.benefit }),
                              ],
                            },
                            t,
                          ),
                        ),
                      }),
                    ],
                  }),
                }),
              ],
            }),
            (0, r.jsx)("section", {
              className: "text-center text-muted-foreground",
              "data-ai-id": "download-footer-text",
              children: (0, r.jsx)("p", {
                children:
                  "That's it! You can now launch EduVish9 just like any other app directly from your home screen.",
              }),
            }),
          ],
        });
      }
    },
    83608: function (e, t, a) {
      "use strict";
      a.d(t, {
        BackButton: function () {
          return l;
        },
      });
      var r = a(57437),
        n = a(99376),
        i = a(12381),
        s = a(5485);
      let l = () => {
        let e = (0, n.useRouter)();
        return (0, r.jsx)("div", {
          className: "mb-4",
          children: (0, r.jsxs)(i.z, {
            onClick: () => e.back(),
            variant: "outline",
            children: [(0, r.jsx)(s.Z, { className: "mr-2 h-4 w-4" }), "Back"],
          }),
        });
      };
    },
    12381: function (e, t, a) {
      "use strict";
      a.d(t, {
        d: function () {
          return d;
        },
        z: function () {
          return o;
        },
      });
      var r = a(57437),
        n = a(2265),
        i = a(98482),
        s = a(90535),
        l = a(93448);
      let d = (0, s.j)(
          "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
          {
            variants: {
              variant: {
                default:
                  "bg-primary text-primary-foreground hover:bg-primary/90",
                destructive:
                  "bg-destructive text-destructive-foreground hover:bg-destructive/90",
                outline:
                  "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
                secondary:
                  "bg-secondary text-secondary-foreground hover:bg-secondary/80",
                ghost: "hover:bg-accent hover:text-accent-foreground",
                link: "text-primary underline-offset-4 hover:underline",
              },
              size: {
                default: "h-10 px-4 py-2",
                sm: "h-9 rounded-md px-3",
                lg: "h-11 rounded-md px-8",
                icon: "h-10 w-10",
              },
            },
            defaultVariants: { variant: "default", size: "default" },
          },
        ),
        o = n.forwardRef((e, t) => {
          let { className: a, variant: n, size: s, asChild: o = !1, ...c } = e,
            u = o ? i.g7 : "button";
          return (0, r.jsx)(u, {
            className: (0, l.cn)(d({ variant: n, size: s, className: a })),
            ref: t,
            ...c,
          });
        });
      o.displayName = "Button";
    },
    79820: function (e, t, a) {
      "use strict";
      a.d(t, {
        Ol: function () {
          return l;
        },
        SZ: function () {
          return o;
        },
        Zb: function () {
          return s;
        },
        aY: function () {
          return c;
        },
        eW: function () {
          return u;
        },
        ll: function () {
          return d;
        },
      });
      var r = a(57437),
        n = a(2265),
        i = a(93448);
      let s = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("div", {
          ref: t,
          className: (0, i.cn)(
            "rounded-lg border bg-card text-card-foreground shadow-sm",
            a,
          ),
          ...n,
        });
      });
      s.displayName = "Card";
      let l = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("div", {
          ref: t,
          className: (0, i.cn)("flex flex-col space-y-1.5 p-6", a),
          ...n,
        });
      });
      l.displayName = "CardHeader";
      let d = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("h3", {
          ref: t,
          className: (0, i.cn)(
            "text-xl font-semibold leading-none tracking-tight",
            a,
          ),
          ...n,
        });
      });
      d.displayName = "CardTitle";
      let o = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("p", {
          ref: t,
          className: (0, i.cn)("text-sm text-muted-foreground", a),
          ...n,
        });
      });
      o.displayName = "CardDescription";
      let c = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("div", {
          ref: t,
          className: (0, i.cn)("p-6 pt-0", a),
          ...n,
        });
      });
      c.displayName = "CardContent";
      let u = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("div", {
          ref: t,
          className: (0, i.cn)("flex items-center p-6 pt-0", a),
          ...n,
        });
      });
      u.displayName = "CardFooter";
    },
    33804: function (e, t, a) {
      "use strict";
      a.d(t, {
        RM: function () {
          return d;
        },
        SC: function () {
          return c;
        },
        iA: function () {
          return s;
        },
        pj: function () {
          return f;
        },
        ss: function () {
          return u;
        },
        xD: function () {
          return l;
        },
        yt: function () {
          return o;
        },
      });
      var r = a(57437),
        n = a(2265),
        i = a(93448);
      let s = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("div", {
          className: "relative w-full overflow-auto",
          children: (0, r.jsx)("table", {
            ref: t,
            className: (0, i.cn)("w-full caption-bottom text-sm", a),
            ...n,
          }),
        });
      });
      s.displayName = "Table";
      let l = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("thead", {
          ref: t,
          className: (0, i.cn)("[&_tr]:border-b", a),
          ...n,
        });
      });
      l.displayName = "TableHeader";
      let d = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("tbody", {
          ref: t,
          className: (0, i.cn)("[&_tr:last-child]:border-0", a),
          ...n,
        });
      });
      d.displayName = "TableBody";
      let o = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("tfoot", {
          ref: t,
          className: (0, i.cn)(
            "border-t bg-muted/50 font-medium [&>tr]:last:border-b-0",
            a,
          ),
          ...n,
        });
      });
      o.displayName = "TableFooter";
      let c = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("tr", {
          ref: t,
          className: (0, i.cn)(
            "border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted",
            a,
          ),
          ...n,
        });
      });
      c.displayName = "TableRow";
      let u = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("th", {
          ref: t,
          className: (0, i.cn)(
            "h-12 px-4 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0",
            a,
          ),
          ...n,
        });
      });
      u.displayName = "TableHead";
      let f = n.forwardRef((e, t) => {
        let { className: a, ...n } = e;
        return (0, r.jsx)("td", {
          ref: t,
          className: (0, i.cn)(
            "p-4 align-middle [&:has([role=checkbox])]:pr-0",
            a,
          ),
          ...n,
        });
      });
      ((f.displayName = "TableCell"),
        (n.forwardRef((e, t) => {
          let { className: a, ...n } = e;
          return (0, r.jsx)("caption", {
            ref: t,
            className: (0, i.cn)("mt-4 text-sm text-muted-foreground", a),
            ...n,
          });
        }).displayName = "TableCaption"));
    },
    93448: function (e, t, a) {
      "use strict";
      a.d(t, {
        cn: function () {
          return i;
        },
      });
      var r = a(61994),
        n = a(53335);
      function i() {
        for (var e = arguments.length, t = Array(e), a = 0; a < e; a++)
          t[a] = arguments[a];
        return (0, n.m6)((0, r.W)(t));
      }
      a(40257);
    },
    5485: function (e, t, a) {
      "use strict";
      a.d(t, {
        Z: function () {
          return r;
        },
      });
      let r = (0, a(96471).Z)("ArrowLeft", [
        ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
        ["path", { d: "M19 12H5", key: "x3x0zl" }],
      ]);
    },
    40655: function (e, t, a) {
      "use strict";
      a.d(t, {
        Z: function () {
          return r;
        },
      });
      let r = (0, a(96471).Z)("HardDriveDownload", [
        ["path", { d: "M12 2v8", key: "1q4o3n" }],
        ["path", { d: "m16 6-4 4-4-4", key: "6wukr" }],
        [
          "rect",
          { width: "20", height: "8", x: "2", y: "14", rx: "2", key: "w68u3i" },
        ],
        ["path", { d: "M6 18h.01", key: "uhywen" }],
        ["path", { d: "M10 18h.01", key: "h775k" }],
      ]);
    },
  },
  function (e) {
    (e.O(0, [167, 2782, 2971, 2117, 1744], function () {
      return e((e.s = 32469));
    }),
      (_N_E = e.O()));
  },
]);
